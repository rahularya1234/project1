function T{
    return (
        <p1>hello word </p1>
    )
}
export default T;