import React from 'react';
import Header from './Header';
import NavBar from './NavBar';
import Banner from './Banner';



const Home = () => {
  return (
    <div className="home">
      <Header />
      <NavBar />
      <Banner/>
      

    </div>
  );
}
export default Home;