
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faHeart, faShoppingCart, faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons';
import styles from '../css/Header.module.css';

const Header = () => {
  return (
    <div className={styles.header}>
      <div className={styles.logo}>
        <img src="../sh.jpeg"  alt="Company Logo" className={styles.logoImage} />
        <span className={styles.companyName}>Company</span>
      
      <div className={styles.delivery}>
        <span><FontAwesomeIcon icon={faMapMarkerAlt} className={styles.locationIcon} /> Deliver to John</span> <br/>
        <span>    Bangalore 560034</span>
      </div>
      </div>
      <div className={styles.icons}>
        <FontAwesomeIcon icon={faUser} className={styles.icon} />
        <FontAwesomeIcon icon={faHeart} className={`${styles.icon} ${styles.heart}`} />
        <div className={styles.cartIcon}>
          <FontAwesomeIcon icon={faShoppingCart} className={`${styles.icon} ${styles.cart}`} />
          <span className={styles.cartCount}>3</span>
        </div>
      </div>
    </div>
  );
}

export default Header;
